# شعارات الخلفية

طلب المستخدم وضع شعار وزارة التعليم وشعار أكاديمية طويق، بهذا الترتيب البصري من اليسار إلى اليمين مع فاصل رأسي. جرى تنزيل النسخ المطابقة من المواقع الرسمية، مع الاحتفاظ بالألوان والشفافية؛ لم تُولّد الشعارات بالذكاء الاصطناعي.

- وزارة التعليم: https://www.moe.gov.sa/Style%20Library/portal/assets/images/moe-logo.svg
- أكاديمية طويق: https://tuwaiq.edu.sa/img/logo.svg

المصدر الثاني يحتوي صورة PNG أصلية بعرض 3037 بكسل داخل حاوية SVG؛ حجمها كافٍ للعرض المصغر في شاشة 4K. العلامات تعود لأصحابها، ومرفقة هنا لاستخدام الشاشة المدرسية الذي طلبه المستخدم.

- qudrat-pro.png: supplied by the project owner for the Qudrat Pro leaderboard integration; preserved without alteration.
